import matplotlib
import matplotlib.pyplot as plt
import os
import copy
import random
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Subset
from datetime import datetime
import warnings

from util.options import args_parser
from util.local_training import LocalUpdate, DALUpdate, globaltest
from util.fedavg import ImpFedAvg, FedAvg
from util.util import add_noise, reliability_score, noise_client, get_set_gpus, write_log
from util.dataset import get_dataset
from model.build_model import build_model

matplotlib.use('Agg')
os.environ["KMP_DUPLICATE_LIB_OK"]="True"
np.set_printoptions(threshold=np.inf)
warnings.filterwarnings("ignore")

if __name__ == '__main__':
    # parse args
    args = args_parser()
    # check time and gpu
    prev_time = datetime.now()
    if args.gpu:
        gpus = get_set_gpus(args.gpu)
        print(f"{torch.cuda.is_available()}, currently use GPU: {gpus}")

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

    '--------------------------------STEP1 divide dataset and add noise--------------------------------'
    dataset_train, dataset_test, y_train, dict_users = get_dataset(args)
    filename = f"result/{args.method}-{args.dataset}-{args.model}-{args.level_n_system}-{args.level_n_lowerb}-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    # filename = f"result/hyperparameters-gamma.txt"
    # write_log(f"\nmethod: {args.method}, dataset: {args.dataset}, gamma: {args.std_num}", filename)
    y_train_noisy, gamma_s, real_noise_level = add_noise(args, y_train, dict_users, filename)
    if args.dataset == 'pmnist':
        dataset_train.labels = y_train_noisy.reshape(-1,1)
    else:
        dataset_train.targets = y_train_noisy

    # build model
    net_glob = build_model(args)
    net_local = build_model(args)
    list_accuracy = []
    list_test_loss = []


    '--------------------------------STEP2 first stage training--------------------------------'
    for iter in range(args.iteration):
        print('----------------Pre-training the {} iteration----------------'.format(iter))
        reli_scores = torch.zeros(args.num_users) if iter == 0 else reli_scores
        w_grob = net_glob.state_dict()
        local_ws = [copy.deepcopy(w_grob)] * args.num_users
        local_losses = [0] * args.num_users
        for idx in range(args.num_users):
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            local = LocalUpdate(args = args, dataset = dataset_train, idxs = sample_idx)
            local_w, local_loss = local.update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                           epoch=args.local_ep, seed=args.seed)
            local_ws[idx] = copy.deepcopy(local_w)
            local_losses[idx] = copy.deepcopy(local_loss)
        client_datalen = [len(dict_users[idx]) for idx in range(args.num_users)]
        reli_score = reliability_score(args, local_losses, client_datalen, filename)
        reli_scores = reli_scores + reli_score

        avg_glob = ImpFedAvg(local_ws, client_datalen, local_losses)
        net_glob.load_state_dict(copy.deepcopy(avg_glob))

    reli_scores = reli_scores / args.iteration
    noise_clients = noise_client(reli_scores, args.std_num, args.delta)

    print('reliability scores:', reli_scores)
    write_log(f"reliability scores: {reli_scores}", filename)
    print('noise clients:', noise_clients)
    write_log(f"noise clients: {noise_clients}, len: {len(noise_clients)}", filename)
    write_log(f"round,loss,acc", filename)


    '--------------------------------STEP3 second stage training--------------------------------'
    for rnd in range(args.rounds):
        print('---------Federated training the {} round---------'.format(rnd))
        w_grob = net_glob.state_dict()
        prob = [1 / args.num_users] * args.num_users
        idxs_users = np.random.choice(range(args.num_users), int(args.num_users*args.frac1), p=prob)
        local_ws, local_losses = [], []
        for idx in idxs_users:
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            if idx in noise_clients:
                t0 = (1 - args.qs) * args.local_ep / (args.qe - args.qs)
                local = DALUpdate(args=args, dataset = dataset_train, idxs = sample_idx, t0 = t0)
                local_w, local_loss = local.update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                                               epoch=args.local_ep, seed=args.seed)
            else:
                local = LocalUpdate(args=args, dataset = dataset_train, idxs = sample_idx)
                local_w, local_loss = local.update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                                           epoch=args.local_ep, seed=args.seed)
            local_ws.append(copy.deepcopy(local_w))
            local_losses.append(copy.deepcopy(local_loss))

        client_datalen = [len(dict_users[idx]) for idx in idxs_users]
        avg_glob = ImpFedAvg(local_ws, client_datalen, local_losses)
        net_glob.load_state_dict(copy.deepcopy(avg_glob))

        test_loss, accuracy = globaltest(copy.deepcopy(net_glob).to(args.device), dataset_test, args)
        list_test_loss.append(test_loss)
        list_accuracy.append(accuracy)
        print(f"loss: {test_loss}, acc: {accuracy}")
        write_log(f"{rnd},{test_loss},{accuracy}", filename)
    write_log(f"The highest accuracy: {max(list_accuracy)}", filename)
    write_log(f"\n", filename)
    write_log(f"list test loss: {list_test_loss}", filename)
    write_log(f"list accuracy: {list_accuracy}", filename)

    cur_time = datetime.now()
    h, remainder = divmod((cur_time - prev_time).seconds, 3600)
    m, s = divmod(remainder, 60)
    time_str = "train time: %02d:%02d:%02d" % (h, m, s)
    print(time_str)
    write_log(time_str, filename)
    torch.cuda.empty_cache()