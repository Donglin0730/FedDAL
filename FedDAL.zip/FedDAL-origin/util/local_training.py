import math
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import numpy as np
from collections import defaultdict

'--------------------------------Global use--------------------------------'
class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label


def globaltest(net, test_dataset, args):
    net.eval()
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=100, shuffle=False, drop_last=True)
    with torch.no_grad():
        correct, total, batch_loss = 0, 0, []
        loss_fn = nn.CrossEntropyLoss()
        for images, labels in test_loader:
            images = images.to(args.device)
            labels = labels.to(args.device)
            labels = labels.squeeze().long()
            outputs = net(images)
            loss = loss_fn(outputs, labels)
            batch_loss.append(loss.item())
            _, log_probsicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (log_probsicted == labels).sum().item()
    test_loss = sum(batch_loss) / len(batch_loss)
    accuracy = round(correct / total, 4)
    return test_loss, accuracy
'--------------------------------Global use--------------------------------'


'--------------------------------losses use--------------------------------'
class MAE(nn.Module):
    def __init__(self, num_classes=10):
        super(MAE, self).__init__()
        self.num_classes = num_classes

    def forward(self, pred, labels):
        pred = F.softmax(pred, dim=1)
        label_one_hot = F.one_hot(labels, self.num_classes).float().to(pred.device)
        loss = 1. - torch.sum(label_one_hot * pred, dim=1)
        return loss.mean()


class GCE(nn.Module):
    def __init__(self, num_classes=10, q=0.7):
        super(GCE, self).__init__()
        self.num_classes = num_classes
        self.q = q

    def forward(self, log_probs, labels):
        log_probs = F.softmax(log_probs, dim=1)
        log_probs = torch.clamp(log_probs, min=1e-6, max=1.0)
        label_one_hot = F.one_hot(labels, self.num_classes).float().to(log_probs.device)
        loss = (1. - torch.pow(torch.sum(label_one_hot * log_probs, dim=1), self.q)) / self.q
        return loss.mean()


class SCE(nn.Module):
    def __init__(self, num_classes=10, alpha=1, beta=1):
        super(SCE, self).__init__()
        self.num_classes = num_classes
        self.alpha = alpha
        self.beta = beta
        self.cross_entropy = nn.CrossEntropyLoss()

    def forward(self, pred, labels):
        ce = self.cross_entropy(pred, labels)
        pred = F.softmax(pred, dim=1)
        pred = torch.clamp(pred, min=1e-6, max=1.0)
        label_one_hot = F.one_hot(labels, self.num_classes).float().to(pred.device)
        label_one_hot = torch.clamp(label_one_hot, min=1e-4, max=1.0)
        rce = (-1 * torch.sum(pred * torch.log(label_one_hot), dim=1))
        rce = rce.mean()

        loss = self.alpha * ce + self.beta * rce
        return loss


class TCE(nn.Module):
    def __init__(self, num_classes=10, order=6):
        super(TCE, self).__init__()
        self.order = order
        self.num_classes = num_classes

    def forward(self, pred, labels):
        batch_size = len(pred)
        pred = F.softmax(pred, dim=1)
        pred = torch.clamp(pred, min=1e-6, max=1.0)
        pred = pred[torch.arange(batch_size), labels].unsqueeze(1)
        matrix = torch.arange(1, self.order + 1).unsqueeze(0).cuda()
        loss = torch.sum((1 - pred) ** matrix / matrix, dim=1)
        return loss.mean()


class GJS(nn.Module):
    def __init__(self, num_classes, pi = 0.5):
        super(GJS, self).__init__()
        self.num_classes = num_classes
        self.weights = [pi, 1 - pi]
        self.scale = -1.0 / ((1.0 - self.weights[0]) * np.log((1.0 - self.weights[0])))

    def forward(self, pred, labels):
        preds = [F.softmax(pred, dim=1)]
        labels = F.one_hot(labels, self.num_classes).float()
        distribs = [labels] + preds
        assert len(self.weights) == len(distribs)

        mean_distrib = sum([w * d for w, d in zip(self.weights, distribs)])
        mean_distrib_log = mean_distrib.clamp(1e-6, 1.0).log()

        jsw = sum([w * custom_kl_div(mean_distrib_log, d) for w, d in zip(self.weights, distribs)])
        return self.scale * jsw


def custom_kl_div(prediction, target):
    output_pos = target * (target.clamp(min=1e-6).log() - prediction)
    zeros = torch.zeros_like(output_pos)
    output = torch.where(target > 0, output_pos, zeros)
    output = torch.sum(output, dim=1)
    return output.mean()


class BS(object):
    def __call__(self, outputs):
        ## hard booststrapping
        targets = torch.argmax(outputs, dim=1)
        return nn.CrossEntropyLoss()(outputs, targets)
        ## soft bootstrapping
        # probs = torch.softmax(outputs, dim=1)
        # return torch.mean(torch.sum(-torch.log(probs+1e-6)*probs, dim=1))
'--------------------------------losses use--------------------------------'

class LocalUpdate(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.loss_func = nn.CrossEntropyLoss(reduction='none')
        self.ldr_train = self.train_split(dataset, list(idxs))

    def train_split(self, dataset, idxs):
        train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return train

    def update_weights(self, net, epoch, seed, lr=None):

        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_class_loss = []
        for iter in range(epoch):
            class_stats, class_metrics = defaultdict(lambda: {'labels': [], 'losses': []}), {}
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.squeeze().long()

                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)
                loss = loss_sample.mean()
                loss.backward()
                optimizer.step()

                # collect labels and losses
                with torch.no_grad():
                    unique_classes = torch.unique(labels)
                    for cls in unique_classes:
                        cls = cls.item()
                        cls_mask = (labels == cls)
                        class_stats[cls]['labels'].append(labels[cls_mask])
                        class_stats[cls]['losses'].append(loss_sample[cls_mask])

            # mean
            for cls, data in class_stats.items():
                cls_losses = torch.cat(data['losses'])
                avg_loss = cls_losses.mean().item()
                cls_count = len(cls_losses)
                class_metrics[cls] = {'avg_loss': avg_loss, 'count': cls_count}

            # filler values
            valid_metrics = [metrics for metrics in class_metrics.values()]
            total_count = sum(metrics['count'] for metrics in valid_metrics)
            avg_loss_filler = sum(metrics['avg_loss'] * metrics['count'] for metrics in valid_metrics) / total_count

            # loss quality score
            class_loss = 0.0
            for cls in range(self.args.num_classes):
                if cls in class_metrics:
                    avg_loss = class_metrics[cls]['avg_loss']
                else:
                    avg_loss = avg_loss_filler
                class_loss += avg_loss

            epoch_class_loss.append(class_loss)
        return net.state_dict(), sum(epoch_class_loss) / len(epoch_class_loss)


class DALUpdate(object):
    def __init__(self, args, dataset, idxs, t0):
        self.args = args
        self.t0 = t0
        self.num_classes = self.args.num_classes
        self.loss_func = nn.CrossEntropyLoss(reduction='none')
        self.ldr_train = self.train_split(dataset, list(idxs))

        self.bs = BS()
        self.mae = MAE(num_classes=self.args.num_classes)
        self.gce = GCE(num_classes=self.args.num_classes)
        self.sce = SCE(num_classes=self.args.num_classes)
        self.gjs = GJS(num_classes=self.args.num_classes)
        self.tce = TCE(num_classes=self.args.num_classes)

    def train_split(self, dataset, idxs):
        train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return train

    def update_weights(self, net, epoch, seed, lr=None):

        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_class_loss = []
        for iter in range(epoch):
            class_stats, class_metrics = defaultdict(lambda: {'labels': [], 'losses': []}), {}
            self.q = self.args.qs + (self.args.qe - self.args.qs) * (iter / epoch)
            self.gce = GCE(num_classes = self.num_classes, q = self.q)
            self.lamb = max(0, (iter - self.t0) / (epoch - self.t0))
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.squeeze().long()

                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)

                if self.args.method == 'fedmae':
                    loss = self.mae(log_probs, labels)
                elif self.args.method == 'fedgce':
                    loss = self.gce(log_probs, labels)
                elif self.args.method == 'fedsce':
                    loss = self.sce(log_probs, labels)
                elif self.args.method == 'fedgjs':
                    loss = self.gjs(log_probs, labels)
                elif self.args.method == 'fedtce':
                    loss = self.tce(log_probs, labels)
                else: # dal
                    loss = self.gce(log_probs, labels) + self.lamb * self.bs(log_probs) / (self.q * np.log(self.num_classes))

                loss.backward()
                optimizer.step()

                # collect labels and losses
                with torch.no_grad():
                    unique_classes = torch.unique(labels)
                    for cls in unique_classes:
                        cls = cls.item()
                        cls_mask = (labels == cls)
                        class_stats[cls]['labels'].append(labels[cls_mask])
                        class_stats[cls]['losses'].append(loss_sample[cls_mask])

            # mean
            for cls, data in class_stats.items():
                cls_losses = torch.cat(data['losses'])
                avg_loss = cls_losses.mean().item()
                cls_count = len(cls_losses)
                class_metrics[cls] = {'avg_loss': avg_loss, 'count': cls_count}

            # filler values
            valid_metrics = [metrics for metrics in class_metrics.values()]
            total_count = sum(metrics['count'] for metrics in valid_metrics)
            avg_loss_filler = sum(
                metrics['avg_loss'] * metrics['count'] for metrics in valid_metrics) / total_count

            # loss quality score
            class_loss = 0.0
            for cls in range(self.args.num_classes):
                if cls in class_metrics:
                    avg_loss = class_metrics[cls]['avg_loss']
                else:
                    avg_loss = avg_loss_filler
                class_loss += avg_loss

            epoch_class_loss.append(class_loss)
        return net.state_dict(), sum(epoch_class_loss) / len(epoch_class_loss)