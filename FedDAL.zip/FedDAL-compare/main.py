import matplotlib
import matplotlib.pyplot as plt
import os
import copy
import random
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Subset, DataLoader, Dataset
from sklearn.mixture import GaussianMixture
from collections import defaultdict
from datetime import datetime
import warnings

from util.options import args_parser
from util.local_training import LocalUpdate, NoRo, ELC, globaltest
from util.fedavg import FedAvg, ImpFedAvg, Focus, DeAgg
from util.util import add_noise, reliability_score, noise_client, consistency_weight, get_set_gpus, write_log
from util.dataset import get_dataset
from model.build_model import build_model
from util.local_training import DatasetSplit

matplotlib.use('Agg')
os.environ["KMP_DUPLICATE_LIB_OK"]="True"
np.set_printoptions(threshold=np.inf)
warnings.filterwarnings("ignore")


if __name__ == '__main__':
    # parse args
    args = args_parser()
    # check time and gpu
    prev_time = datetime.now()
    if args.gpu:
        gpus = get_set_gpus(args.gpu)
        print(f"{torch.cuda.is_available()}, currently use GPU: {gpus}")

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


    '--------------------------------STEP1 divide dataset and add noise--------------------------------'
    dataset_train, dataset_test, y_train, dict_users = get_dataset(args)
    filename = f"result/{args.method}-{args.dataset}-{args.model}-{args.level_n_system}-{args.level_n_lowerb}-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    # filename = f"result/noise-detection-{args.dataset}-{args.model}.txt"
    # write_log(f"\nmethod: {args.method}, noisy client ratio: {args.level_n_system}, lower bound: {args.level_n_lowerb}", filename)
    y_train_noisy, gamma_s, real_noise_level = add_noise(args, y_train, dict_users, filename)
    if args.dataset == 'pmnist':
        dataset_train.labels = y_train_noisy.reshape(-1, 1)
    else:
        dataset_train.targets = y_train_noisy

    # build model
    net_glob = build_model(args)
    net_local = build_model(args)
    list_accuracy = []
    list_test_loss = []


    '--------------------------------STEP2 first stage training--------------------------------'
    for iter in range(args.iteration):
        print('---------Pre-training the {} iteration---------'.format(iter))
        w_glob = net_glob.state_dict()
        w_locals = [copy.deepcopy(w_glob)] * args.num_users
        loss_locals = [0] * args.num_users
        for idx in range(args.num_users):
            net_local.load_state_dict(w_glob)
            sample_idx = np.array(list(dict_users[idx]))
            local = LocalUpdate(args = args, dataset = dataset_train, idxs = sample_idx)
            w, loss = local.normal_update(net=copy.deepcopy(net_glob).to(args.device), epoch=args.local_ep, seed=args.seed)
            w_locals[idx]=copy.deepcopy(w)
            loss_locals[idx]=copy.deepcopy(loss)

        client_datalen = [len(dict_users[idx]) for idx in range(args.num_users)]
        avg_glob = FedAvg(w_locals, client_datalen, loss_locals)
        net_glob.load_state_dict(avg_glob)

        if args.method == 'fedncl':
            if iter == 0:
                wc = torch.zeros((len(w_glob.keys()), len(w_locals)))
                paratmeter_key_list = list(w_glob.keys())
                for client in range(len(w_locals)):
                    for k in w_glob.keys():
                        w_d = w_glob[k] - w_locals[client][k]
                        wc[paratmeter_key_list.index(k), client] = torch.norm(w_d.float(), 2).cpu()
                total_w = wc.sum(dim=0)
                datasize = torch.from_numpy(np.array(client_datalen))
                loss_locals = torch.from_numpy(np.array(loss_locals))
                reli_score = total_w * loss_locals / datasize.float()

                noisy_clients = reli_score * (abs(reli_score - reli_score.mean()) > args.beta * reli_score.std())
                noisy_clients = noisy_clients.nonzero().view(-1).tolist()
                print("noisy clients: ", noisy_clients)
                write_log(f"noise clients: {noisy_clients}, len: {len(noisy_clients)}", filename)
                write_log(f"round,loss,acc", filename)

        if args.method == 'fednoro' or args.method == 'fedelc':
            if iter == 0:
                metrics = np.zeros((args.num_users, args.num_classes))
                ce = nn.CrossEntropyLoss(reduction='none')
                for idx in range(args.num_users):
                    class_loss = np.zeros(args.num_classes)
                    class_count = np.zeros(args.num_classes)

                    loader = DataLoader(DatasetSplit(dataset_train, sample_idx), batch_size=args.local_bs, shuffle=True)
                    for data, labels in loader:
                        data, labels = data.to(args.device), labels.to(args.device)
                        if data.size(0) <= 1: continue

                        logits = net_glob(data)
                        labels = labels.squeeze().long()
                        losses = ce(logits, labels).cpu().detach().numpy()
                        for label, loss in zip(labels.cpu().numpy(), losses):
                            class_loss[label] += loss
                            class_count[label] += 1

                    loss_collect = []
                    for cls in range(args.num_classes):
                        if class_count[cls] > 0:
                            loss_collect.append(class_loss[cls] / class_count[cls])
                            metrics[idx, cls] = class_loss[cls] / class_count[cls]
                    for cls in range(args.num_classes):
                        if class_count[cls] == 0:
                            metrics[idx, cls] = min(loss_collect)

                for cls in range(args.num_classes):
                    col = metrics[:, cls]
                    min_val, max_val = col.min(), col.max()
                    if max_val - min_val > 1e-6:
                        metrics[:, cls] = (col - min_val) / (max_val - min_val)
                    else:
                        metrics[:, cls] = 0.0

                vote = []
                for seed in range(9):
                    gmm = GaussianMixture(n_components=2, random_state=seed)
                    gmm.fit(metrics)

                    noisy_cluster_id = np.argmax(gmm.means_.sum(axis=1))
                    pred_labels = gmm.predict(metrics)
                    noisy_clients = np.where(pred_labels == noisy_cluster_id)[0]
                    vote.append(set(noisy_clients))

                cluster_cnt = defaultdict(int)
                for client_set in vote:
                    cluster_cnt[frozenset(client_set)] += 1

                most_common_set = max(cluster_cnt, key=lambda k: cluster_cnt[k])
                noisy_clients = list(most_common_set)
                clean_clients = list(set(range(args.num_users)) - set(noisy_clients))
                print("noisy clients: ", noisy_clients)
                write_log(f"noise clients: {noisy_clients}, len: {len(noisy_clients)}", filename)
                write_log(f"round,loss,acc", filename)


    '--------------------------------STEP3 second stage training--------------------------------'
    for rnd in range(args.rounds):
        print('---------Federated training the {} round---------'.format(rnd))
        w_grob = net_glob.state_dict()
        prob = [1 / args.num_users] * args.num_users
        idxs_users = np.random.choice(range(args.num_users), int(args.num_users*args.frac1), p=prob)
        client_datalen = [len(dict_users[idx]) for idx in idxs_users]
        w_locals, loss_locals = [], []
        # models training
        for idx in idxs_users:
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            if args.method == 'fednoro':
                weight_kd = consistency_weight(rnd, 0, (args.rounds / 2)) * 0.8
                if idx in noisy_clients:
                    local = NoRo(args=args, dataset = dataset_train, idxs = sample_idx)
                    w_local, loss_local = local.noro_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed, weight_kd)
                else:
                    local = LocalUpdate(args=args, dataset = dataset_train, idxs = sample_idx)
                    w_local, loss_local = local.normal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            elif args.method == 'fedelc':
                if idx in noisy_clients:
                    local = ELC(args=args, dataset=dataset_train, idxs=sample_idx)
                    w_local, loss_local = local.elc_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)
                else:
                    local = LocalUpdate(args=args, dataset=dataset_train, idxs=sample_idx)
                    w_local, loss_local = local.normal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            else:
                local = LocalUpdate(args=args, dataset=dataset_train, idxs=sample_idx)
                w_local, loss_local = local.normal_update(copy.deepcopy(net_glob).to(args.device), args.local_ep, args.seed)

            w_locals.append(copy.deepcopy(w_local))
            loss_locals.append(copy.deepcopy(loss_local))
        # model aggregation
        if args.method == 'fednoro':
            select_clean = [c for c in range(len(idxs_users)) if idxs_users[c] in clean_clients]
            select_noisy = [c for c in range(len(idxs_users)) if idxs_users[c] in noisy_clients]
            if len(select_clean) == 0:
                w_glob = FedAvg(w_locals, client_datalen, loss_locals)
            else:
                w_glob = DeAgg(idxs_users, client_datalen, w_locals, select_clean, select_noisy)

        elif args.method == 'fedelc':
            select_clean = [c for c in range(len(idxs_users)) if idxs_users[c] in clean_clients]
            select_noisy = [c for c in range(len(idxs_users)) if idxs_users[c] in noisy_clients]
            if len(select_clean) == 0:
                w_glob = FedAvg(w_locals, client_datalen, loss_locals)
            else:
                w_glob = DeAgg(idxs_users, client_datalen, w_locals, select_clean, select_noisy)

        elif args.method == 'focus':
            w_glob = Focus(w_locals, client_datalen, loss_locals)

        else:
            w_glob = FedAvg(w_locals, client_datalen, loss_locals)
        net_glob.load_state_dict(copy.deepcopy(w_glob))

        test_loss, accuracy = globaltest(copy.deepcopy(net_glob).to(args.device), dataset_test, args)
        list_accuracy.append(accuracy)
        list_test_loss.append(test_loss)
        print(f"loss: {test_loss}, acc: {accuracy}")
        write_log(f"{rnd},{test_loss},{accuracy}", filename)
    write_log(f"The highest accuracy: {max(list_accuracy)}", filename)

    # output time
    cur_time = datetime.now()
    h, remainder = divmod((cur_time - prev_time).seconds, 3600)
    m, s = divmod(remainder, 60)
    time_str = "train time: %02d:%02d:%02d" % (h, m, s)
    print(time_str)
    write_log(time_str, filename)
    torch.cuda.empty_cache()
