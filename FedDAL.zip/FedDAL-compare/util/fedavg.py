import copy
import torch
import numpy as np


def FedAvg(w, dict_len, value):
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        w_avg[k] = w_avg[k] * dict_len[0]
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * dict_len[i]
        w_avg[k] = w_avg[k] / sum(dict_len)
    return w_avg


def ImpFedAvg(w, dict_len, value):
    weight = [0] * len(w)
    min_value = min(value)
    max_value = max(value)
    for idx in range(len(value)):
        value[idx] = (value[idx] - min_value) / (max_value-min_value)
    for i in range(len(weight)):
        weight[i] = dict_len[i] * np.exp(-value[i])
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        w_avg[k] = w_avg[k] * weight[0]
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * weight[i]
        w_avg[k] = w_avg[k] / sum(weight)
    return w_avg


def Focus(w, dict_len, value):
    beta = 1.0
    weight = [0] * len(w)
    sum_exp_ei = sum(np.exp(beta * np.array(value)))
    for idx in range(len(weight)):
        ck = 1 - (np.exp(beta * value[idx]) / sum_exp_ei)
        weight[idx] = dict_len[idx] * ck
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        w_avg[k] = w_avg[k] * weight[0]
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * weight[i]
        w_avg[k] = w_avg[k] / sum(weight)
    return w_avg


def DeAgg(select, client_datalen, update_dict, select_clean, select_noisy):

    distance = np.zeros(len(select))
    weight = [client_datalen[i] / sum(client_datalen) for i in range(len(select))]
    for i in select_noisy:
        min_dist = np.inf
        for j in select_clean:
            dist = model_dist(update_dict[i], update_dict[j])
            min_dist = dist if dist < min_dist else min_dist
        distance[i] = min_dist

    distance_norm = distance / np.max(distance) if np.max(distance) > 1e-6 else np.zeros_like(distance)
    weight = weight * np.exp(-distance_norm)
    model_dict = copy.deepcopy(update_dict[0])

    for k in model_dict.keys():
        model_dict[k] = model_dict[k] * weight[0]
        for i in range(1, len(update_dict)):
            model_dict[k] += update_dict[i][k] * weight[i]
        model_dict[k] = model_dict[k] / sum(weight)
    return model_dict


def model_dist(w_1, w_2):
    assert w_1.keys() == w_2.keys(), "Keys mismatch."
    dist_total = torch.zeros(1).float()
    for key in w_1.keys():
        if "int" in str(w_1[key].dtype):
            continue
        dist = torch.norm(w_1[key] - w_2[key])
        dist_total += dist.cpu()
    return dist_total.cpu().item()


