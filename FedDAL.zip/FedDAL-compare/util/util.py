import numpy as np
import torch
import torch.nn.functional as F
import copy
from scipy.spatial.distance import cdist


def get_set_gpus(gpu_ids):
    # get gpu ids
    if len(gpu_ids) > 1:
        str_ids = gpu_ids.split(',')
        gpus = []
        for str_id in str_ids:
            id = int(str_id)
            if id >= 0:
                gpus.append(id)
    else:
        gpus = [int(gpu_ids)]
    # set gpu ids
    if len(gpus) > 0:
        torch.cuda.set_device(gpus[0])
        return gpu_ids


def write_log(message, filename):
    with open(filename, 'a') as file:
        file.write(message + "\n")


def consistency_weight(current, begin, end):
    current = np.clip(current, begin, end)
    phase = 1.0 - (current-begin) / (end-begin)
    return float(np.exp(-5.0 * phase * phase))


def add_noise(args, y_train, dict_users, filename):
    np.random.seed(args.seed)

    gamma_s = np.random.binomial(1, args.level_n_system, args.num_users)
    gamma_c_initial = np.random.rand(args.num_users)
    gamma_c_initial = (1 - args.level_n_lowerb) * gamma_c_initial + args.level_n_lowerb
    gamma_c = gamma_s * gamma_c_initial

    y_train_noisy = copy.deepcopy(y_train)

    real_noise_level = np.zeros(args.num_users)
    for i in np.where(gamma_c > 0)[0]:
        sample_idx = np.array(list(dict_users[i]))
        prob = np.random.rand(len(sample_idx))
        noisy_idx = np.where(prob <= gamma_c[i])[0]
        y_train_noisy[sample_idx[noisy_idx]] = np.random.randint(0, args.num_classes, len(noisy_idx))
        noise_ratio = np.mean(y_train[sample_idx] != y_train_noisy[sample_idx])
        real_noise_level[i] = noise_ratio
        write_log(f"Client {i}, noise level: {gamma_c[i]:.4f} ({gamma_c[i] * 0.9:.4f}), real noise ratio: {noise_ratio:.4f}", filename)
    return (y_train_noisy, gamma_s, real_noise_level)


def reliability_score(args, w_locals, w_glob, loss_locals, client_datalen):
    wc = torch.zeros((len(w_glob.keys()), len(w_locals)))
    paratmeter_key_list = list(w_glob.keys())
    for client in range(len(w_locals)):
        for k in w_glob.keys():
            wc[paratmeter_key_list.index(k), client] = distance(w_glob[k], w_locals[client][k]).cpu() + 1
    all_w = wc.sum(dim=0)
    datasize = torch.from_numpy(np.array(client_datalen))
    loss_locals = torch.from_numpy(np.array(loss_locals))
    reli_score = all_w * loss_locals / datasize
    return reli_score

def distance(w_global, w_local):
    w_d = w_global - w_local
    w_d = w_d.float()
    return torch.norm(w_d, 2)  # L2


def noise_client(list_reli_score, delta, std_num):
    print('reliability score:',list_reli_score)
    sorted_values, sorted_indices = torch.sort(list_reli_score)
    distances = sorted_values[1:] - sorted_values[:-1]
    max_distance_index = torch.argmax(distances)
    distances_after_max_index = sorted_values[max_distance_index + 1:] - sorted_values[max_distance_index]
    sorted_values[max_distance_index + 1:] = sorted_values[max_distance_index + 1:] * np.exp(distances_after_max_index[0:] / -delta)
    mean_reli_score = sorted_values.mean()
    std_reli_score = torch.std(list_reli_score - mean_reli_score)
    noise_client = list_reli_score * (abs(list_reli_score - mean_reli_score) > std_num * std_reli_score)
    noise_client = noise_client.nonzero().view(-1).tolist()
    print('noise clients list:',noise_client)
    return noise_client