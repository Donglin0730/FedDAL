import copy
import math
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import numpy as np


'--------------------------------Global use--------------------------------'
class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.images = torch.stack([dataset[i][0] for i in idxs])
        self.labels = torch.tensor([dataset[i][1] for i in idxs])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        return self.images[index], self.labels[index]

    @property
    def tensor(self):
        return (self.images, self.labels)


def globaltest(net, test_dataset, args):
    net.eval()
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=100, shuffle=False, drop_last=True)
    with torch.no_grad():
        correct, total, batch_loss = 0, 0, []
        loss_fn = nn.CrossEntropyLoss()
        for images, labels in test_loader:
            images = images.to(args.device)
            labels = labels.to(args.device)
            labels = labels.squeeze().long()
            outputs = net(images)
            loss = loss_fn(outputs, labels)
            batch_loss.append(loss.item())
            _, log_probsicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (log_probsicted == labels).sum().item()
    test_loss = sum(batch_loss) / len(batch_loss)
    accuracy = round(correct / total, 4)
    return test_loss, accuracy
'--------------------------------Global use--------------------------------'


'--------------------------------GJS use--------------------------------'
class GJS(nn.Module):
    def __init__(self, num_classes, pi = 0.5):
        super(GJS, self).__init__()
        self.num_classes = num_classes
        self.weights = [pi, 1 - pi]
        self.scale = -1.0 / ((1.0 - self.weights[0]) * np.log((1.0 - self.weights[0])))

    def forward(self, pred, labels):
        preds = [F.softmax(pred, dim=1)]
        labels = F.one_hot(labels, self.num_classes).float()
        distribs = [labels] + preds
        assert len(self.weights) == len(distribs)

        mean_distrib = sum([w * d for w, d in zip(self.weights, distribs)])
        mean_distrib_log = mean_distrib.clamp(1e-6, 1.0).log()

        jsw = sum([w * custom_kl_div(mean_distrib_log, d) for w, d in zip(self.weights, distribs)])
        return self.scale * jsw


def custom_kl_div(prediction, target):
    output_pos = target * (target.clamp(min=1e-6).log() - prediction)
    zeros = torch.zeros_like(output_pos)
    output = torch.where(target > 0, output_pos, zeros)
    output = torch.sum(output, dim=1)
    return output.mean()
'--------------------------------GJS use--------------------------------'


'--------------------------------FedNoRo use--------------------------------'
class LA_KD(nn.Module):
    def __init__(self, cls_num_list, tau=1):
        super(LA_KD, self).__init__()
        cls_num_list = torch.as_tensor(cls_num_list, device='cuda')
        cls_p_list = cls_num_list / cls_num_list.sum()
        m_list = tau * torch.log(cls_p_list)
        self.m_list = m_list.view(1, -1)

    def forward(self, x, target, soft_target, w_kd):
        x_m = x + self.m_list
        log_pred = torch.log_softmax(x_m, dim=-1)
        log_pred = torch.where(torch.isinf(log_pred), torch.full_like(log_pred, 0), log_pred)

        kl = F.kl_div(log_pred, soft_target, reduction='batchmean')

        return w_kd * kl + (1 - w_kd) * F.nll_loss(log_pred, target)


class LogitAdjust(nn.Module):
    def __init__(self, cls_num_list, tau=1, weight=None):
        super(LogitAdjust, self).__init__()
        cls_num_list = torch.as_tensor(cls_num_list, device='cuda')
        cls_p_list = cls_num_list / cls_num_list.sum()
        m_list = tau * torch.log(cls_p_list)
        self.m_list = m_list.view(1, -1)
        self.weight = weight

    def forward(self, x, target):
        x_m = x + self.m_list
        return F.cross_entropy(x_m, target, weight=self.weight)
'--------------------------------FedNoRo use--------------------------------'


'--------------------------------FedELC use--------------------------------'
class DatasetSplit_ELC(Dataset):
    def __init__(self, dataset, idxs):
        self.images = torch.stack([dataset[i][0] for i in idxs])
        self.labels = torch.tensor([dataset[i][1] for i in idxs])

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        return self.images[index], self.labels[index], index

    @property
    def tensor(self):
        return (self.images, self.labels)
'--------------------------------FedELC use--------------------------------'


class LocalUpdate(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.trainset = DatasetSplit(dataset, idxs)
        self.ldr_train = self.train_load()

        self.loss_fn = nn.CrossEntropyLoss()

        self.gjs = GJS(num_classes=self.args.num_classes, pi=self.args.pi)

        self.class_num_list = torch.bincount(self.trainset.tensor[1].squeeze(), minlength=self.args.num_classes).tolist()
        self.noro = LogitAdjust(cls_num_list=self.class_num_list)

    def train_load(self):
        trainset = DataLoader(self.trainset, batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return trainset

    def normal_update(self, net, epoch, seed, lr=None):
        net_glob=copy.deepcopy(net)
        net.train()
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(epoch):
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.squeeze().long()

                net.zero_grad()
                log_probs = net(images)

                if self.args.method == 'fedavg':
                    loss = self.loss_fn(log_probs, labels)

                elif self.args.method == 'fedncl':
                    loss = self.loss_fn(log_probs, labels)

                elif self.args.method == 'fedprox':
                    loss = self.loss_fn(log_probs, labels)
                    proximal_term = 0.0
                    for param, param_g in zip(net.parameters(), net_glob.parameters()):
                        proximal_term += ((self.args.beta / 2.) * torch.norm(param - param_g, p=2).pow(2))
                    loss = loss + proximal_term

                elif self.args.method == 'focus':
                    loss = self.loss_fn(log_probs, labels)

                elif self.args.method == 'gjs':
                    loss = self.gjs(log_probs, labels)

                elif self.args.method == 'fednoro':
                    loss = self.noro(log_probs, labels)

                elif self.args.method == 'fedelc':
                    loss = self.noro(log_probs, labels)

                else:
                    print("Method input error!")

                loss.backward()
                optimizer.step()

                batch_loss.append(loss.item())
            epoch_loss.append(sum(batch_loss)/len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)


class NoRo(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.trainset = DatasetSplit(dataset, idxs)
        self.ldr_train = self.train_load()

        self.class_num_list = torch.bincount(self.trainset.tensor[1].squeeze(), minlength=self.args.num_classes).tolist()
        self.loss_fn = LA_KD(cls_num_list=self.class_num_list)

    def train_load(self):
        trainset = DataLoader(self.trainset, batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return trainset

    def noro_update(self, net, epoch, seed, weight_kd, lr=None):
        teacher = copy.deepcopy(net)
        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(epoch):
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.squeeze().long()

                net.zero_grad()
                log_probs = net(images)
                with torch.no_grad():
                    teacher_logits = teacher(images)
                    soft_label = torch.softmax(teacher_logits / 0.8, dim=1)
                loss = self.loss_fn(log_probs, labels, soft_label, weight_kd)
                loss.backward()
                optimizer.step()

                batch_loss.append(loss.item())
            epoch_loss.append(sum(batch_loss) / len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)


class ELC(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.trainset = DatasetSplit_ELC(dataset, idxs)
        self.ldr_train = self.train_load()
        self.alpha, self.beta, self.lamda = 0.2, 0.5, 0.1
        self.soft_labels = None

    def train_load(self):
        trainset = DataLoader(self.trainset, batch_size=self.args.local_bs, shuffle=True, drop_last=True)
        return trainset

    def elc_update(self, net, epoch, seed, lr=None):
        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        if self.soft_labels is None:
            num_samples = len(self.trainset)
            self.soft_labels = torch.zeros(num_samples, self.args.num_classes)
            all_labels = self.trainset.labels.squeeze().long()
            self.soft_labels[torch.arange(num_samples), all_labels] = 10.0

        epoch_loss = []
        for iter in range(epoch):
            batch_loss = []
            labels_grad = torch.zeros_like(self.soft_labels)
            for batch_idx, (images, labels, indexs) in enumerate(self.ldr_train):
                images = images.to(self.args.device)
                labels = labels.to(self.args.device)
                labels = labels.squeeze().long()
                soft_labels = self.soft_labels[indexs].to(self.args.device)
                soft_labels.requires_grad_(True)

                net.zero_grad()
                log_probs = net(images)
                pred = F.softmax(log_probs, dim=1)
                Lo = -torch.mean(F.log_softmax(soft_labels, dim=1)[torch.arange(soft_labels.shape[0]), labels])
                Le = -torch.mean(torch.sum(F.log_softmax(log_probs, dim=1) * pred, dim=1))
                Lc = -torch.mean(torch.sum(F.log_softmax(soft_labels, dim=1) * pred, dim=1)) - Le
                loss = Lc / self.args.num_classes + self.alpha * Lo + self.beta * Le / self.args.num_classes

                loss.backward()
                optimizer.step()

                labels_grad[indexs] = soft_labels.grad.detach().cpu()
                del soft_labels

                batch_loss.append(loss.item())
            self.soft_labels = self.soft_labels - self.lamda * labels_grad

            epoch_loss.append(sum(batch_loss) / len(batch_loss))
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)
