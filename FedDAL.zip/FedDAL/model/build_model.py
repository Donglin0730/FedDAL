from model.lenet import LeNet
from model.model_resnet import ResNet18, ResNet34
from model.model_resnet_official import ResNet50
import torchvision.models as models
import torch.nn as nn


def build_model(args):
    # choose different Neural network model for different args or input
    if args.model == 'lenet':
        net_glob = LeNet().to(args.device)

    elif args.model == 'resnet18':
        net_glob = ResNet18(args.num_classes)
        net_glob = net_glob.to(args.device)

    elif args.model == 'resnet34':
        net_glob = ResNet34(args.num_classes)
        net_glob = net_glob.to(args.device)

    elif args.model == 'resnet50':
        net_glob = ResNet50(pretrained=False)
        if args.pretrained:
            model = models.resnet50(pretrained=True)
            net_glob.load_state_dict(model.state_dict())
        net_glob.fc = nn.Linear(2048, args.num_classes)
        net_glob = net_glob.to(args.device)

    elif args.model == 'vgg11':
        net_glob = models.vgg11()
        net_glob.fc = nn.Linear(4096, args.num_classes)
        net_glob = net_glob.to(args.device)

    else:
        exit('Error: unrecognized model')

    return net_glob
