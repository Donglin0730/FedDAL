# python version 3.7.1
# -*- coding: utf-8 -*-

import math
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import numpy as np
from collections import defaultdict


class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label


class LocalUpdate(object):
    def __init__(self, args, dataset, idxs):
        self.args = args
        self.loss_func = nn.CrossEntropyLoss(reduction='none')
        self.ldr_train, self.ldr_test = self.train_test(dataset, list(idxs))

    def train_test(self, dataset, idxs):
        # split training set, validation set and test set
        train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True)
        test = DataLoader(dataset, batch_size=128)
        return train, test

    def update_weights(self, net, epoch, seed, lr=None):

        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(epoch):
            class_loss = defaultdict(lambda: {'total_loss': 0.0, 'count': 0})
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images, labels = images.to(self.args.device), labels.to(self.args.device)
                labels = labels.long()

                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)
                loss = loss_sample.mean()
                loss.backward()
                optimizer.step()

                with torch.no_grad():
                    unique_classes, counts = torch.unique(labels, return_counts=True)
                    for cls, cnt in zip(unique_classes, counts):
                        cls, cnt = cls.item(), cnt.item()
                        cls_mask = (labels == cls)
                        cls_total_loss = loss_sample[cls_mask].sum().item()
                        class_loss[cls]['total_loss'] += cls_total_loss
                        class_loss[cls]['count'] += cnt

            valid_classes = [cls for cls in class_loss if class_loss[cls]['count'] > 0]
            num_valid_classes = len(valid_classes)
            if num_valid_classes > 0:
                total_avg_loss = sum(
                    class_loss[cls]['total_loss'] / class_loss[cls]['count']
                    for cls in valid_classes)
                weighted_epoch_loss = total_avg_loss / num_valid_classes
            
            epoch_loss.append(weighted_epoch_loss)
        
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)

class DAL(object):
    def __init__(self, args, dataset, idxs, t0):
        self.args = args
        self.t0 = t0
        self.bs = BS()
        self.num_classes = self.args.num_classes
        self.ldr_train, self.ldr_test = self.train_test(dataset, list(idxs))
        self.loss_func = nn.CrossEntropyLoss(reduction='none')

    def train_test(self, dataset, idxs):
        # split training set, validation set and test set
        train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True)
        test = DataLoader(dataset, batch_size=128)
        return train, test

    def dal_update_weights(self, net, epoch, seed, lr=None):

        net.train()
        # train and update
        if lr is None:
            optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        else:
            optimizer = torch.optim.SGD(net.parameters(), lr=lr, momentum=self.args.momentum)

        epoch_loss = []
        for iter in range(epoch):
            class_loss = defaultdict(lambda: {'total_loss': 0.0, 'count': 0})
            self.q = self.args.qs + (self.args.qe - self.args.qs) * (iter / epoch)
            self.gce = GCE(num_classes = self.num_classes, q = self.q)
            self.lamb = max(0, (iter - self.t0) / (epoch - self.t0))
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images, labels = images.to(self.args.device), labels.to(self.args.device)

                labels = labels.long()
                net.zero_grad()
                log_probs = net(images)
                loss_sample = self.loss_func(log_probs, labels)
                loss = self.gce(log_probs, labels) + self.lamb * self.bs(log_probs) / (self.q * np.log(self.num_classes))
                loss.backward()
                optimizer.step()

                with torch.no_grad():
                    unique_classes, counts = torch.unique(labels, return_counts=True)
                    for cls, cnt in zip(unique_classes, counts):
                        cls, cnt = cls.item(), cnt.item()
                        cls_mask = (labels == cls)
                        cls_total_loss = loss_sample[cls_mask].sum().item()
                        class_loss[cls]['total_loss'] += cls_total_loss
                        class_loss[cls]['count'] += cnt

            valid_classes = [cls for cls in class_loss if class_loss[cls]['count'] > 0]
            num_valid_classes = len(valid_classes)
            if num_valid_classes > 0:
                total_avg_loss = sum(
                    class_loss[cls]['total_loss'] / class_loss[cls]['count']
                    for cls in valid_classes)
                weighted_epoch_loss = total_avg_loss / num_valid_classes
            
            epoch_loss.append(weighted_epoch_loss)
        return net.state_dict(), sum(epoch_loss) / len(epoch_loss)

class GCE(nn.Module):
    def __init__(self, num_classes=10, q=0.7):
        super(GCE, self).__init__()
        self.num_classes = num_classes
        self.q = q

    def forward(self, log_probs, labels):
        log_probs = F.softmax(log_probs, dim=1)
        log_probs = torch.clamp(log_probs, min=1e-6, max=1.0)
        label_one_hot = F.one_hot(labels, self.num_classes).float().to(log_probs.device)
        loss = (1. - torch.pow(torch.sum(label_one_hot * log_probs, dim=1), self.q)) / self.q
        return loss.mean()

class BS(object):
    def __call__(self, outputs):
        ## hard booststrapping
        targets = torch.argmax(outputs, dim=1)
        return nn.CrossEntropyLoss()(outputs, targets)
        ## soft bootstrapping
        # probs = torch.softmax(outputs, dim=1)
        # return torch.mean(torch.sum(-torch.log(probs+1e-6)*probs, dim=1))

def globaltest(net, test_dataset, args):
    net.eval()
    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=100, shuffle=False)
    with torch.no_grad():
        correct = 0
        total = 0
        for images, labels in test_loader:
            images = images.to(args.device)
            labels = labels.to(args.device)
            outputs = net(images)
            _, log_probsicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (log_probsicted == labels).sum().item()

    acc = correct / total
    return round(acc,4)
