# python version 3.7.1
# -*- coding: utf-8 -*-

import argparse

def args_parser():
    parser = argparse.ArgumentParser()
    # federated arguments
    parser.add_argument('--iteration1', type=int, default=1, help="enumerate iteration in preprocessing stage")
    parser.add_argument('--rounds', type=int, default=200, help="rounds of training in usual training stage")
    parser.add_argument('--local_ep', type=int, default=5, help="number of local epochs")
    parser.add_argument('--frac1', type=float, default=0.2, help="fration of selected clients in usual training stage")
    parser.add_argument('--std_num', type=float, default=1, help="the number of standard deviations of the mean")

    parser.add_argument('--num_users', type=int, default=50, help="number of uses: K")
    parser.add_argument('--local_bs', type=int, default=10, help="local batch size: B")
    parser.add_argument('--lr', type=float, default=0.03, help="learning rate")
    parser.add_argument('--momentum', type=float, default=0.5, help="SGD momentum, default 0.5")
    parser.add_argument('--gpu', default='0,1', help='comma separated list of GPU(s) to use.')
    parser.add_argument('--device', type=str, default='cuda')

    # noise arguments
    parser.add_argument('--delta', type=int, default=2, help="tolerance value")
    parser.add_argument('--level_n_system', type=float, default=0.4, help="fraction of noisy clients,[0.4, 0.7]")
    parser.add_argument('--level_n_lowerb', type=float, default=0.3, help="lower bound of noise level,[0.3,0.5,0.7]")

    # other arguments
    parser.add_argument('--model', type=str, default='resnet18', help="model name")
    parser.add_argument('--dataset', type=str, default='cifar10', help="name of dataset")
    parser.add_argument('--pretrained', action='store_true', help="whether to use pre-trained model")
    parser.add_argument('--iid', action='store_true', default=False, help="i.i.d. or non-i.i.d.")
    parser.add_argument('--non_iid_prob_class', type=float, default=0.7, help="label plob")
    parser.add_argument('--alpha_dirichlet', type=float, default=10)
    parser.add_argument('--num_classes', type=int, default=10, help="number of classes")
    parser.add_argument('--seed', type=int, default=6, help="random seed, default: 1")
    parser.add_argument("--qs", type=float, default=0.8)
    parser.add_argument("--qe", type=float, default=1.5)

    return parser.parse_args()
