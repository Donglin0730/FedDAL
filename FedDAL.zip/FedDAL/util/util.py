import os
import torch
import copy
import numpy as np
import torch.nn.functional as F
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
os.environ["OMP_NUM_THREADS"] = "1"


def add_noise(args, y_train, dict_users):
    np.random.seed(args.seed)

    gamma_s = np.random.binomial(1, args.level_n_system, args.num_users)
    gamma_c_initial = np.random.rand(args.num_users)
    gamma_c_initial = (1 - args.level_n_lowerb) * gamma_c_initial + args.level_n_lowerb
    gamma_c = gamma_s * gamma_c_initial

    y_train_noisy = copy.deepcopy(y_train)

    real_noise_level = np.zeros(args.num_users)
    for i in np.where(gamma_c > 0)[0]:
        sample_idx = np.array(list(dict_users[i]))
        prob = np.random.rand(len(sample_idx))
        noisy_idx = np.where(prob <= gamma_c[i])[0]
        y_train_noisy[sample_idx[noisy_idx]] = np.random.randint(0, 10, len(noisy_idx))
        noise_ratio = np.mean(y_train[sample_idx] != y_train_noisy[sample_idx])
        print("Client %d, noise level: %.4f (%.4f), real noise ratio: %.4f" % (i, gamma_c[i], gamma_c[i] * 0.9, noise_ratio))
        real_noise_level[i] = noise_ratio
    return (y_train_noisy, gamma_s, real_noise_level)


def reliability_score(args, w_locals, w_glob, loss_locals, client_datalen):
    wc = torch.zeros((len(w_glob.keys()), len(w_locals)))
    paratmeter_key_list = list(w_glob.keys())
    for client in range(len(w_locals)):
        for k in w_glob.keys():
            wc[paratmeter_key_list.index(k), client] = distance(w_glob[k], w_locals[client][k]).cpu() + 1
    all_w = wc.sum(dim=0)
    datasize = torch.from_numpy(np.array(client_datalen))
    loss_locals = torch.from_numpy(np.array(loss_locals))
    reli_score = all_w * loss_locals / datasize
    return reli_score

def distance(w_global, w_local):
    w_d = w_global - w_local
    w_d = w_d.float()
    return torch.norm(w_d, 2)


def noise_client(original_scores, std_num, delta):
    print('reliability score:', original_scores)

    # FedDAL
    sorted_values, sorted_indices = torch.sort(original_scores)
    distances = sorted_values[1:] - sorted_values[:-1]
    max_index = torch.argmax(distances).item()
    boundary_point = sorted_values[max_index]
    # kmeans
    scores_np = original_scores.numpy().reshape(-1, 1)
    scaler = StandardScaler()
    scores_scaled = scaler.fit_transform(scores_np)
    kmeans = KMeans(n_clusters=2, n_init=100, max_iter=100, random_state=0)
    kmeans.fit(scores_scaled)
    centroids = scaler.inverse_transform(kmeans.cluster_centers_).flatten()
    small_centroid, large_centroid = np.sort(centroids)
    # boundary point
    if torch.abs(boundary_point - small_centroid) < torch.abs(boundary_point - large_centroid):
        boundary_point = sorted_values[max_index]
    else:
        boundary_point = small_centroid

    std_ori = torch.std(original_scores, unbiased=False)
    sorted_truncated = sorted_values.clone()
    sorted_truncated[sorted_truncated > boundary_point] = boundary_point
    mean_reli = sorted_truncated.mean()
    std_trun = torch.std(sorted_truncated, unbiased=False)
    trunc_ratio = (original_scores > boundary_point).float().mean()
    hybrid_std = (trunc_ratio**2) * std_ori + (1 - trunc_ratio**2) * std_trun
    noise_threshold = mean_reli + std_num * hybrid_std
    noise_mask = original_scores > noise_threshold
    noise_clients = noise_mask.nonzero().view(-1).tolist()

    # GMM
    # scores_np = original_scores.numpy().reshape(-1, 1)
    # scaler = StandardScaler()
    # scores_scaled = scaler.fit_transform(scores_np)
    # gmm = GaussianMixture(n_components=2, covariance_type='diag', max_iter=100, random_state=0)
    # gmm.fit(scores_scaled)
    # means = scaler.inverse_transform(gmm.means_).flatten()
    # noise_cluster_idx = np.argmax(means)
    # noise_mask = gmm.predict(scores_scaled) == noise_cluster_idx
    # noise_clients = np.where(noise_mask)[0].tolist()

    print('noise clients list:', noise_clients)
    return noise_clients