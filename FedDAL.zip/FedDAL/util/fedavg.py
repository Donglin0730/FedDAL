# python version 3.7.1
# -*- coding: utf-8 -*-

import copy
import torch
import numpy as np

def ImpFedAvg(w, dict_len, value):
    weight = [0] * len(w)
    min_value = min(value)
    max_value = max(value)
    for idx in range(len(value)):
        value[idx] = (value[idx] - min_value) / (max_value-min_value)
    for i in range(len(weight)):
        weight[i] = dict_len[i] * np.exp(-value[i])
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():        
        w_avg[k] = w_avg[k] * weight[0]
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * weight[i]
        w_avg[k] = w_avg[k] / sum(weight)
    return w_avg


def FedAvg(w, dict_len, value):
    w_avg = copy.deepcopy(w[0])
    for k in w_avg.keys():
        w_avg[k] = w_avg[k] * dict_len[0]
        for i in range(1, len(w)):
            w_avg[k] += w[i][k] * dict_len[i]
        w_avg[k] = w_avg[k] / sum(dict_len)
    return w_avg

