# python version 3.7.1
# -*- coding: utf-8 -*-

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="True"
import copy
import random
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Subset

from datetime import datetime
from util.options import args_parser
from util.local_training import LocalUpdate, DAL, globaltest
from util.fedavg import ImpFedAvg, FedAvg
from util.util import add_noise, reliability_score, noise_client
from util.dataset import get_dataset
from model.build_model import build_model

np.set_printoptions(threshold=np.inf)

def get_set_gpus(gpu_ids):
    # get gpu ids
    if len(gpu_ids) > 1:
        str_ids = gpu_ids.split(',')
        gpus = []
        for str_id in str_ids:
            id = int(str_id)
            if id >= 0:
                gpus.append(id)
    else:
        gpus = [int(gpu_ids)]
    # set gpu ids
    if len(gpus) > 0:
        torch.cuda.set_device(gpus[0])
        return gpu_ids

if __name__ == '__main__':
    # parse args
    args = args_parser()

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

    # divide the training set and test set
    prev_time = datetime.now()
    # print(torch.cuda.is_available())
    if args.gpu:
        gpus = get_set_gpus(args.gpu)
        print('==>Currently use GPU: {}'.format(gpus))
    dataset_train, dataset_test, dict_users = get_dataset(args)

    # add Noise
    y_train = np.array(dataset_train.targets)
    y_train_noisy, gamma_s, real_noise_level = add_noise(args, y_train, dict_users)
    dataset_train.targets = y_train_noisy

    # build model
    net_glob = build_model(args)
    net_local = build_model(args)

    # ---------------------first stage training---------------------
    for iteration in range(args.iteration1):
        if iteration == 0:
            list_reli_score = torch.zeros(args.num_users)
        print('---------Pre-training the {} iteration---------'.format(iteration))
        w_grob = net_glob.state_dict()
        w_locals = [copy.deepcopy(w_grob)] * args.num_users
        loss_locals = [0] * args.num_users
        for idx in range(args.num_users):
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            local = LocalUpdate(args = args, dataset = dataset_train, idxs = sample_idx)
            w, loss = local.update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                           epoch=args.local_ep, seed=args.seed)
            w_locals[idx]=copy.deepcopy(w)
            loss_locals[idx]=copy.deepcopy(loss)
        
        client_datalen = [len(dict_users[idx]) for idx in range(args.num_users)]
        reli_score=reliability_score(args, w_locals, w_grob, loss_locals, client_datalen)
        list_reli_score=list_reli_score+reli_score

        avg_glob = ImpFedAvg(w_locals, client_datalen, loss_locals)
        net_glob.load_state_dict(copy.deepcopy(avg_glob))
    
    list_reli_score = list_reli_score/args.iteration1
    noise_client = noise_client(list_reli_score, args.std_num, args.delta)


    list_acc=[]
    # ---------------------second stage training---------------------
    for rnd in range(args.rounds):
        print('---------Federated training the {} round---------'.format(rnd))
        w_grob = net_glob.state_dict()
        prob = [1 / args.num_users] * args.num_users
        idxs_users = np.random.choice(range(args.num_users), int(args.num_users*args.frac1), p=prob)
        w_locals, loss_locals = [], []
        for idx in idxs_users:
            net_local.load_state_dict(w_grob)
            sample_idx = np.array(list(dict_users[idx]))

            if idx in noise_client:
                t0 = (1 - args.qs) * args.local_ep / (args.qe - args.qs)
                local = DAL(args=args, dataset = dataset_train, idxs = sample_idx, t0 = t0)
                w_local, loss_local = local.dal_update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                                               epoch=args.local_ep, seed=args.seed)
            else:
                local = LocalUpdate(args=args, dataset = dataset_train, idxs = sample_idx)
                w_local, loss_local = local.update_weights(net=copy.deepcopy(net_glob).to(args.device),
                                                           epoch=args.local_ep, seed=args.seed)
            w_locals.append(copy.deepcopy(w_local))
            loss_locals.append(copy.deepcopy(loss_local))

        client_datalen = [len(dict_users[idx]) for idx in idxs_users]
        w_glob = ImpFedAvg(w_locals, client_datalen, loss_locals) # FedDAL uses FedAvg if dataset is animal10.
        net_glob.load_state_dict(copy.deepcopy(w_glob))
    
        acc = globaltest(copy.deepcopy(net_glob).to(args.device), dataset_test, args)
        print('The {} round acc:'.format(rnd), acc)
        list_acc.append(acc)

    print('The highest accuracy:', max(list_acc))

    cur_time = datetime.now()
    h, remainder = divmod((cur_time - prev_time).seconds, 3600)
    m, s = divmod(remainder, 60)
    time_str = "train time %02d:%02d:%02d" % (h, m, s)
    print(time_str)
    torch.cuda.empty_cache()